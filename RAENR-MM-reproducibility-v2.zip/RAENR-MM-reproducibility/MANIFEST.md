# Manifest

Version 2, 2026-08-22. SHA-256 checksums for every file.

Changed since v1: README line references corrected (see README section 0).
No code, result or conclusion differs from v1.

| File | Bytes | SHA-256 (first 16) | Description |
|---|---|---|---|
| `README.md` | 13,261 | `0a30f68c6ec52bef` | This document. |
| `analysis/cd_sweep.cpp` | 1,519 | `14ee0a5e6d1e64b6` | Compiled coordinate-descent kernel (also emitted by run_shard.R). |
| `analysis/combine_shards.R` | 5,271 | `9ff58a42065a8c28` | Merges shard outputs; refuses to run on an incomplete set. |
| `analysis/export_diagnostics.R` | 1,327 | `7a76e16b03879c02` | Collinearity diagnostics (Table A1). |
| `analysis/extract_stability.R` | 3,572 | `3f12c799639ac7e1` | Selection frequencies and Jaccard indices (Tables S5-S8b). |
| `analysis/inspect_shard1.R` | 4,763 | `ccaf31a3c0546db1` | Summaries, ranks and paired comparisons from one run file. |
| `analysis/run_all_shards.bat` | 1,568 | `b4f5299fcfddffa3` | Windows launcher for a 4-way split of the replications. |
| `analysis/run_shard.R` | 28,120 | `50ca728885a916b7` | Main leakage-free analysis. Standalone; produces shard_NN.rds. |
| `results/shard1_diagnostics.csv` | 380 | `76cf7976a6e9b783` | Collinearity diagnostics incl. legacy_kappa_top300 (Table A1). |
| `results/shard1_paired.csv` | 1,087 | `c71681463813b19a` | Paired RAENR-MM vs MM-RWAL comparisons, R=1000. |
| `results/shard1_stability.csv` | 2,765 | `0830e6260c5d5de8` | Selection stability measures, R=1000. |
| `results/shard1_summ.csv` | 8,395 | `8ee58850774edd0e` | Per framework/dimensionality/estimator summaries, R=1000. |
| `superseded/GSE14520_Real_Analysis_1.Rmd` | 40,367 | `22a91504d75cd972` | Original pipeline. NOT used for any reported result. |

## Full checksums

```
0a30f68c6ec52bef03e662d0c95d4fd5ba923d41775b7765eaea39b011a2136c  README.md
14ee0a5e6d1e64b62c86cda86b41e5d74e5d2bdfaf83bf33dfcd302649c41318  analysis/cd_sweep.cpp
9ff58a42065a8c284c6f0f15dd0c8773ea88ee0c3fe70bfe7d0b8ce029baaba8  analysis/combine_shards.R
7a76e16b03879c024a52256922a0903cd1a33d061f7c793d2158086272321465  analysis/export_diagnostics.R
3f12c799639ac7e15b4e2cc924ee1bdf062f61d385510d32833461d3eaf0bd4e  analysis/extract_stability.R
ccaf31a3c0546db12a122619c999d6fd2a68c4cea27fab70692f59475642cc31  analysis/inspect_shard1.R
b4f5299fcfddffa38489b78b4fa4ba28d31b6bd561d4008bf137a8d703233e6c  analysis/run_all_shards.bat
50ca728885a916b768ce444621e866c374b1b817c7e9104cb37da3e1c58090db  analysis/run_shard.R
76cf7976a6e9b783e141ae31e145c11f76277f774b97eb9f6427f7238013fb9a  results/shard1_diagnostics.csv
c71681463813b19a252da7bf54365a4d4c5ab3dce9903f73d757c21083e6d8dc  results/shard1_paired.csv
0830e6260c5d5de8cbc8100aa24dffa363f7a172587c4c6ccab8c86bf6bf6c4b  results/shard1_stability.csv
8ee58850774edd0e343ef83c9cd44bac8a95a393af040e5569d11b6a1e35ef5e  results/shard1_summ.csv
22a91504d75cd9720632d0a1e447534f33aea274e8c99b5cf7d0e0f68da109ab  superseded/GSE14520_Real_Analysis_1.Rmd
```

## Portability

All paths are relative. Environment variables override the defaults:

- `GSE14520_PATH` — GEO series matrix (default: beside `run_shard.R`)
- `RAENR_OUT` — output directory (default: `./raenr_out`)
- `RAENR_BUILD` — kernel build directory (default: under `tempdir()`)

On Windows keep the build path short; a deeply nested path can exceed
MAX_PATH and fail with a `CreateProcess` error.

## Not included

No simulation code: the simulation study has been withdrawn from the
manuscript and no reported claim depends on it (README section 2a).

Development scaffolding from debugging the compiled kernel and the
parallel-execution machinery is omitted; none of it participates in the analysis.

The GEO series matrix is not redistributed; see README section 3.
